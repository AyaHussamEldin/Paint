//#pragma once
//
//#include "operation.h"
//#include "..\shapes\shape.h"
//#include "..\controller.h"
//#include "..\GUI\GUI.h"
//#include "..\shapes\Rect.h"
//#include "../Shapes/Shape.h"
//#include "../Shapes/Graph.h"
//#include "../controller.h"
//#include "../GUI/GUI.h"
//#include <iostream>
//
//// Save operation class
//class opLoad : public operation
//{
//public:
//    opLoad(controller* pCont);
//    virtual ~opLoad();
//    shape* CreateShape(string shapeType);
//    
//    virtual void Execute();
//};
//
