//#pragma once
//
//#include "operation.h"
//
//// Save operation class
//class opSave : public operation
//{
//public:
//    opSave(controller* pCont);
//    virtual ~opSave();
//
//    // Save data in the controller
//    virtual void Execute();
//};
//
